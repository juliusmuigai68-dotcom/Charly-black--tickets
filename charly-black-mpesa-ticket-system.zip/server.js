import express from 'express';
import crypto from 'node:crypto';
import {Pool} from 'pg';

const app=express();
app.use(express.json({limit:'100kb'}));
app.use(express.static('.'));
const PORT=process.env.PORT||10000;
const pool=new Pool({connectionString:process.env.DATABASE_URL,ssl:process.env.DATABASE_URL?{rejectUnauthorized:false}:false});

const prices={
  'Regular Ticket':2000,
  'VIP — Unreserved Seating':3500,
  'VIP Table of 7':50000
};

async function db(){
  await pool.query(`CREATE TABLE IF NOT EXISTS orders(
    id text primary key, phone text not null, items jsonb not null, amount integer not null,
    status text not null default 'PENDING', checkout_request_id text, mpesa_receipt text,
    ticket_code text unique, created_at timestamptz default now(), paid_at timestamptz
  )`);
}

function normalizePhone(v){
  let p=String(v||'').replace(/\D/g,'');
  if(p.startsWith('07')||p.startsWith('01')) p='254'+p.slice(1);
  if(p.startsWith('7')||p.startsWith('1')) p='254'+p;
  if(!/^254[17]\d{8}$/.test(p)) throw new Error('Enter a valid Kenyan M-Pesa number.');
  return p;
}
function total(items){
  if(!Array.isArray(items)||!items.length) throw new Error('No tickets selected.');
  let sum=0;
  for(const x of items){
    if(!prices[x.name]||!Number.isInteger(x.qty)||x.qty<1||x.qty>20) throw new Error('Invalid ticket selection.');
    sum+=prices[x.name]*x.qty;
  }
  return sum;
}
async function token(){
  const key=process.env.MPESA_CONSUMER_KEY, secret=process.env.MPESA_CONSUMER_SECRET;
  if(!key||!secret) throw new Error('M-Pesa API credentials are not configured.');
  const base=process.env.MPESA_ENV==='production'?'https://api.safaricom.co.ke':'https://sandbox.safaricom.co.ke';
  const r=await fetch(base+'/oauth/v1/generate?grant_type=client_credentials',{headers:{Authorization:'Basic '+Buffer.from(key+':'+secret).toString('base64')}});
  const j=await r.json(); if(!r.ok||!j.access_token) throw new Error('Could not authenticate with M-Pesa.'); return {token:j.access_token,base};
}

app.post('/api/stkpush',async(req,res)=>{
  try{
    const phone=normalizePhone(req.body.phone); const amount=total(req.body.items);
    const orderId='ORD-'+crypto.randomBytes(8).toString('hex').toUpperCase();
    const {token:access,base}=await token();
    const shortCode=process.env.MPESA_SHORTCODE, passkey=process.env.MPESA_PASSKEY, callback=process.env.MPESA_CALLBACK_URL;
    if(!shortCode||!passkey||!callback) throw new Error('M-Pesa shortcode, passkey or callback URL is missing.');
    const ts=new Date().toISOString().replace(/\D/g,'').slice(0,14);
    const password=Buffer.from(String(shortCode)+passkey+ts).toString('base64');
    const body={BusinessShortCode:String(shortCode),Password:password,Timestamp:ts,
      TransactionType:process.env.MPESA_TRANSACTION_TYPE||'CustomerPayBillOnline',Amount:amount,
      PartyA:phone,PartyB:String(process.env.MPESA_PARTY_B||shortCode),PhoneNumber:phone,
      CallBackURL:callback,AccountReference:orderId,TransactionDesc:'Mass House Charly Black ticket'};
    const r=await fetch(base+'/mpesa/stkpush/v1/processrequest',{method:'POST',headers:{Authorization:'Bearer '+access,'Content-Type':'application/json'},body:JSON.stringify(body)});
    const j=await r.json(); if(!r.ok||j.ResponseCode!=='0') throw new Error(j.errorMessage||j.ResponseDescription||'M-Pesa STK request failed.');
    await pool.query('INSERT INTO orders(id,phone,items,amount,checkout_request_id) VALUES($1,$2,$3,$4,$5)',[orderId,phone,JSON.stringify(req.body.items),amount,j.CheckoutRequestID]);
    res.json({ok:true,orderId,checkoutRequestId:j.CheckoutRequestID,message:'Check your phone and enter your M-Pesa PIN.'});
  }catch(e){res.status(400).json({ok:false,error:e.message});}
});

app.post('/api/mpesa/callback',async(req,res)=>{
  try{
    const c=req.body?.Body?.stkCallback;
    if(!c){return res.json({ResultCode:0,ResultDesc:'Accepted'});}
    const id=c.CheckoutRequestID; const success=String(c.ResultCode)==='0';
    let receipt=null;
    if(success){const meta=c.CallbackMetadata?.Item||[]; receipt=meta.find(x=>x.Name==='MpesaReceiptNumber')?.Value||null;}
    if(success){
      const ticket='CHB-'+crypto.randomBytes(7).toString('hex').toUpperCase();
      await pool.query(`UPDATE orders SET status='PAID',mpesa_receipt=$1,ticket_code=$2,paid_at=now() WHERE checkout_request_id=$3 AND status='PENDING'`,[receipt,ticket,id]);
    }else{
      await pool.query(`UPDATE orders SET status='FAILED' WHERE checkout_request_id=$1 AND status='PENDING'`,[id]);
    }
    res.json({ResultCode:0,ResultDesc:'Accepted'});
  }catch(e){res.json({ResultCode:0,ResultDesc:'Accepted'});}
});

app.get('/api/order/:id',async(req,res)=>{
  const r=await pool.query('SELECT id,items,amount,status,mpesa_receipt,ticket_code,created_at,paid_at FROM orders WHERE id=$1',[req.params.id]);
  if(!r.rowCount)return res.status(404).json({error:'Order not found'});
  res.json(r.rows[0]);
});

app.get('/{*splat}',(req,res)=>res.sendFile(process.cwd()+'/index.html'));
await db();
app.listen(PORT,()=>console.log('Charly Black ticket server listening on '+PORT));
